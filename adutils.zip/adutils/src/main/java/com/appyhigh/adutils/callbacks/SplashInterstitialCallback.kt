package com.appyhigh.adutils.callbacks

interface SplashInterstitialCallback {
    fun moveNext()
}