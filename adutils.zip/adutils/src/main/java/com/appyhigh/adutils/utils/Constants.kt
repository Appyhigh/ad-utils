package com.appyhigh.adutils.utils

object HttpConstants {
    const val AUTHORIZATION_HEADER = "Authorization"
    const val TIMEOUT_INTERVAL = 30L //In seconds
}
