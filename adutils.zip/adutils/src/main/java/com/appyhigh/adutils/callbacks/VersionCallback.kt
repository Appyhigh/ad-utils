package com.appyhigh.adutils.callbacks

interface VersionCallback {
    fun OnSoftUpdate()
    fun OnHardUpdate()

}